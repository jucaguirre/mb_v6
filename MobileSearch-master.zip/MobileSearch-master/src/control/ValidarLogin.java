/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import entidad.Admin;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import mb_version_3.IncludePanel;
import mb_version_3.LoginPanel;


/**
 *
 * @author usuario
 */
public class ValidarLogin {

    ArrayList<Admin> admin = new ArrayList<Admin>();
    

    public void passLogin(){
    /*char clave[]=jpassClave.getPassword();

        String clavedef=new String(clave);


       if (txtUsuario.getText().equals("Administrador") && clavedef.equals("12345")){


                    //this.dispose();


                    JOptionPane.showMessageDialog(null, "Bienvenido\n"
                    + "Has ingresado satisfactoriamente al sistema",   "Mensaje de bienvenida",
                    JOptionPane.INFORMATION_MESSAGE);


                    //Formulario1 formformulario1 = new Formulario1();

                    //formformulario1.setVisible(true);
                    LoginPanel.setVisible(false);
                    LoginPanel.removeAll();
                    LoginPanel.add(include);
                    LoginPanel.setVisible(true);


            }else {


                    JOptionPane.showMessageDialog(null, "Acceso denegado:\n"
                    + "Por favor ingrese un usuario y/o contraseña correctos", "Acceso denegado",
                    JOptionPane.ERROR_MESSAGE);
           

            }*/
    }
      
}
